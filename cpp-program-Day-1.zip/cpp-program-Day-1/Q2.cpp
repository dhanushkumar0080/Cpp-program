//Write a C++ Program to print the given word.
#include <iostream>
using namespace std;
int main()
{
    char ch;
    cout<<"Enter Any Character : ";
    cin>>ch;
    cout<<ch;
    return 0;
}
