//Write a C++ Program to print the given integer number.
#include <iostream>
using namespace std;
int main()
{
    int age;
    cout<<"Enter your Age : ";
    cin>>age;
    cout<<"Your Age is : "<<age;
    return 0;
}
