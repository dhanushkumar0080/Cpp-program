//Write a C++  Program to print Welcome
#include <iostream>
using namespace std;
int main()
{
    cout<<"Welcome...";

    return 0;
}
