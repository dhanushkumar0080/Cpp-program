//Write a C++ Program to print the given hexadecimal number in integer format.
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    int num;
    cout<<"Enter a number : ";
    cin>>hex>>num;
    cout<<num;
    return 0;
}
