//Write a C++ Program to print the given message.
#include <iostream>
using namespace std;
int main()
{
    string str;
    cout<<"Enter your name : ";
    cin>>str;
    cout<<"Your name is : "<<str;
    return 0;
}
